GLMr
====

R package for basic GLM model running
