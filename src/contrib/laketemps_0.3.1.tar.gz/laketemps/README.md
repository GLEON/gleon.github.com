laketemps
=========

lake temperature data package for GLTC

[![Build status](https://ci.appveyor.com/api/projects/status/314c58ibg5351g0n?svg=true)](https://ci.appveyor.com/project/jread-usgs/laketemps)
