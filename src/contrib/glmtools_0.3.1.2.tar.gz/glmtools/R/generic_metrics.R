#holder for glmtools metrics that follow rLA conventions
#'@export
water.temperature <- function(wtr){
  wtr
}