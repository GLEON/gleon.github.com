
# .onAttach <- function(libname, pkgname) {
# 	
# 	#Check that current GLM version is up to date
# 	tmpfile = tempfile()
# 	if(!download.file('https://raw.githubusercontent.com/GLEON/GLMr/master/DESCRIPTION',
# 								tmpfile, quiet=TRUE, cacheOK=TRUE, method='internal')){
# 		
# 		online_version = read.dcf(tmpfile, fields='Version')
# 		if(!is.na(online_version)){
# 			
# 			curr_version = as.numeric(packageVersion(pkgname))
# 			online_version = as.numeric(online_version)
# 			
# 			if(curr_version < online_version){
# 				packageStartupMessage("Your version of GLMr is out of date. Please run:\n", 
# 								"install.packages('GLMr', repos='http://gleon.github.com', type='source')")
# 			}else{
# 				packageStartupMessage('Your GLMr package is up to date.')
# 			}
# 		}else{
# 			packageStartupMessage("Unable to determine if your GLM version is up to date.")
# 		}
# 	}
# 
# }
# 

