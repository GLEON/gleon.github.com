library(testthat)
library(glmtools)

test_check("glmtools")